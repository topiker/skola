package numberGenerator;

/**
 * Created by liska on 21.01.2018.
 * Typy generatoru pouzitych v systemu
 */
public enum GeneratorType
{
    EXP,
    GAUSS
}
