package network;

/**
 * Created by liska on 20.01.2018.
 */
public enum NetworkSchema
{
    MENZA
}
